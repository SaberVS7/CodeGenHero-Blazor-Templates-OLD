﻿using System;

namespace $safeprojectname$.Infrastucture
{
    public interface IRepositoryActionResult<T> where T : class
    {
        T Entity { get; }
        Exception Exception { get; }
        Enums.RepositoryActionStatus Status { get; }
    }
}