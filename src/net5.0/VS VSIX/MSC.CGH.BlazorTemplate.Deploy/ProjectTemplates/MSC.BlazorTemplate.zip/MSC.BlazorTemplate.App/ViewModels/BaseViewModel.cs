﻿using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Options;
using $safeprojectname$.Services;
using $ext_safeprojectname$.Shared.DTO;

namespace $safeprojectname$.ViewModels
{
    public class BaseViewModel : ComponentBase
    {
        public string ImagesBaseAddress
        {
            get
            {
                return MSCAppSettings.ImagesBaseAddress;
            }
        }

        [Inject]
        public NavigationManager NavigationManager { get; set; }

        [Inject]
        public INavigationService NavigationService { get; set; }

        public MSCAppSettings MSCAppSettings
        {
            get
            {
                return MSCAppSettingsOptions.Value;
            }
        }

        [Inject]
        public IOptions<MSCAppSettings> MSCAppSettingsOptions { get; set; }
    }
}