﻿window.blazorExtensions = {
    ScrollToTop: function () {
        document.documentElement.scrollTop = 0;
    },
};