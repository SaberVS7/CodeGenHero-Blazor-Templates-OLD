window.BlazorEnvironment = 'Development'; 
