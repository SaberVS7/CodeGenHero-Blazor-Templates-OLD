﻿namespace $safeprojectname$.Configuration
{
    public class AppSettingPathConstants
    {
        public const string AppInsightsKey = "AppInsights:InstrumentationKey";
    }
}